# HELP

## Params Analysis 

Input Assuming: m*100, n*1000

So, inputs always has a magnitude of 100K.

To calculate the cost of memory, I added the summary into model constructing file.